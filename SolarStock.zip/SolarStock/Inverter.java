import java.time.LocalDate;

// INHERITANCE: Inverter IS-A Product
class Inverter extends Product {

    private double capacityKw;

    public Inverter(String productId, String name, double unitPrice, int quantity,
                    int reorderLevel, String supplierId,
                    LocalDate warrantyEndDate, LocalDate expiryDate, double capacityKw) {
        super(productId, name, unitPrice, quantity, reorderLevel,
                supplierId, warrantyEndDate, expiryDate);
        setCapacityKw(capacityKw);
    }

    public double getCapacityKw() {
        return capacityKw;
    }

    public void setCapacityKw(double capacityKw) {
        if (Double.isNaN(capacityKw) || Double.isInfinite(capacityKw) || capacityKw <= 0) {
            throw new InventoryException("Inverter capacity must be greater than zero.");
        }
        this.capacityKw = capacityKw;
    }

    @Override
    public String getCategory() {
        return "Inverter";
    }

    @Override
    public String getSpecification() {
        return capacityKw + "kW";
    }

    @Override
    public String getSpecificationValue() {
        return String.valueOf(capacityKw);
    }

    @Override
    public void setSpecification(String value) {
        try {
            setCapacityKw(Double.parseDouble(value.trim()));
        } catch (NumberFormatException error) {
            throw new InventoryException("Capacity must be a number.");
        }
    }

    @Override
    public double calculateStorageRisk() {
        if (capacityKw >= 10) {
            return 3.0;
        }
        return 1.0;
    }
}
