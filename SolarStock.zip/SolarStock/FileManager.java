import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

// Handles all file reading and writing (saving, loading and exporting).
class FileManager {

    private static final String PRODUCT_FILE = "products.csv";
    private static final String SUPPLIER_FILE = "suppliers.csv";
    private static final String TRANSACTION_FILE = "transactions.csv";

    // ---------- SAVE ----------
    public boolean saveAll(Inventory inventory) {
        try {
            PrintWriter supplierWriter = new PrintWriter(new FileWriter(SUPPLIER_FILE));
            supplierWriter.println("SupplierID,Name,Contact");
            for (Supplier supplier : inventory.getSuppliers()) {
                supplierWriter.println(supplier.toCsvLine());
            }
            supplierWriter.close();

            PrintWriter productWriter = new PrintWriter(new FileWriter(PRODUCT_FILE));
            productWriter.println("Category,ProductID,Name,UnitPrice,Quantity,ReorderLevel,"
                    + "SupplierID,WarrantyEnd,ExpiryDate,Specification");
            for (Product product : inventory.getProducts()) {
                productWriter.println(product.toCsvLine());
            }
            productWriter.close();

            PrintWriter transactionWriter = new PrintWriter(new FileWriter(TRANSACTION_FILE));
            transactionWriter.println("Sequence,Type,ProductID,Quantity,Timestamp,Note,Reversed");
            for (StockTransaction transaction : inventory.getTransactions()) {
                transactionWriter.println(transaction.toCsvLine());
            }
            transactionWriter.close();
            return true;
        } catch (IOException error) {
            System.out.println("Warning: data could not be saved. " + error.getMessage());
            return false;
        }
    }

    // ---------- LOAD ----------
    // Returns true if saved data was loaded. Returns false if the files are missing or damaged.
    public boolean loadAll(Inventory inventory) {
        File productFile = new File(PRODUCT_FILE);
        if (!productFile.exists()) {
            return false;                      // no saved data yet: the program uses sample data
        }

        try {
            File supplierFile = new File(SUPPLIER_FILE);
            if (supplierFile.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(supplierFile));
                reader.readLine();             // skip the header line
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) {
                        continue;
                    }
                    String[] parts = line.split(",", -1);
                    inventory.addLoadedSupplier(new Supplier(parts[0], parts[1], parts[2]));
                }
                reader.close();
            }

            BufferedReader productReader = new BufferedReader(new FileReader(productFile));
            productReader.readLine();          // skip the header line
            String productLine;
            while ((productLine = productReader.readLine()) != null) {
                if (productLine.trim().isEmpty()) {
                    continue;
                }
                String[] parts = productLine.split(",", -1);
                Product product = ProductFactory.createProduct(parts[0], parts[1], parts[2],
                        Double.parseDouble(parts[3]), Integer.parseInt(parts[4]),
                        Integer.parseInt(parts[5]), parts[6], parseDate(parts[7]),
                        parseDate(parts[8]), parts[9]);
                inventory.addLoadedProduct(product);
            }
            productReader.close();

            File transactionFile = new File(TRANSACTION_FILE);
            if (transactionFile.exists()) {
                BufferedReader transactionReader = new BufferedReader(new FileReader(transactionFile));
                transactionReader.readLine();  // skip the header line
                String transactionLine;
                while ((transactionLine = transactionReader.readLine()) != null) {
                    if (transactionLine.trim().isEmpty()) {
                        continue;
                    }
                    String[] parts = transactionLine.split(",", -1);
                    inventory.addLoadedTransaction(new StockTransaction(
                            Integer.parseInt(parts[0]), parts[1], parts[2],
                            Integer.parseInt(parts[3]), LocalDateTime.parse(parts[4]),
                            parts[5], Boolean.parseBoolean(parts[6])));
                }
                transactionReader.close();
            }
            System.out.println("Saved data loaded.");
            return true;
        } catch (Exception error) {
            System.out.println("Saved files could not be read (" + error.getMessage()
                    + "). Sample data will be used.");
            inventory.clearAll();
            return false;
        }
    }

    private LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        return LocalDate.parse(text.trim());
    }

    // ---------- EXPORT ----------
    public boolean fileExists(String fileName) {
        return new File(fileName).exists();
    }

    public String getFullPath(String fileName) {
        return new File(fileName).getAbsolutePath();
    }

    public void exportInventoryCsv(String fileName, Inventory inventory) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(fileName));
        writer.println("ID,Name,Category,Price,Quantity,Reorder Level,Specification,"
                + "Supplier ID,Warranty End,Expiry Date");
        for (Product product : inventory.getProducts()) {
            writer.println(product.getProductId() + "," + product.getName() + ","
                    + product.getCategory() + "," + product.getUnitPrice() + ","
                    + product.getQuantity() + "," + product.getReorderLevel() + ","
                    + product.getSpecification() + "," + product.getSupplierId() + ","
                    + product.getWarrantyEndText() + "," + product.getExpiryDateText());
        }
        writer.close();
    }

    public void exportTransactionsCsv(String fileName, Inventory inventory) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(fileName));
        writer.println("Sequence,Type,Product ID,Quantity,Date and Time,Note,Reversed");
        for (StockTransaction transaction : inventory.getTransactions()) {
            writer.println(transaction.toCsvLine());
        }
        writer.close();
    }

    public void exportSummaryTxt(String fileName, Inventory inventory) throws IOException {
        PrintWriter writer = new PrintWriter(new FileWriter(fileName));
        writer.println("SOLARSTOCK INVENTORY SUMMARY");
        writer.println("Generated: " + LocalDateTime.now().toString().replace("T", " "));
        writer.println("----------------------------------------");
        writer.println("Total products : " + inventory.getProductCount());
        writer.println("Total units    : " + inventory.getTotalUnits());
        writer.printf("Total value    : PHP %,.2f%n", inventory.getTotalValue());

        writer.println();
        writer.println("CATEGORY SUMMARY");
        writer.printf("%-14s %9s %9s %20s%n", "CATEGORY", "PRODUCTS", "UNITS", "VALUE (PHP)");
        String[][] table = inventory.getCategorySummaryTable();
        for (int row = 0; row < table.length; row++) {
            writer.printf("%-14s %9s %9s %20s%n", table[row][0], table[row][1],
                    table[row][2], table[row][3]);
        }

        writer.println();
        writer.println("LOW-STOCK LIST");
        ArrayList<Product> lowStockList = inventory.getLowStockProducts();
        if (lowStockList.isEmpty()) {
            writer.println("No low-stock products.");
        }
        for (Product product : lowStockList) {
            writer.println(product.getProductId() + " - " + product.getName()
                    + " - Qty: " + product.getQuantity());
        }
        writer.close();
    }
}
