import java.time.LocalDate;

// ABSTRACTION: Product is the abstract parent of SolarPanel, Inverter and Battery.
abstract class Product implements CsvRecord {

    // 1. private fields (ENCAPSULATION)
    private String productId;
    private String name;
    private double unitPrice;
    private int quantity;
    private int reorderLevel;
    private String supplierId;
    private LocalDate warrantyEndDate;
    private LocalDate expiryDate;

    // 2. constructor (it uses the setters so the values are checked)
    public Product(String productId, String name, double unitPrice, int quantity,
                   int reorderLevel, String supplierId,
                   LocalDate warrantyEndDate, LocalDate expiryDate) {
        setProductId(productId);
        setName(name);
        setUnitPrice(unitPrice);
        setQuantity(quantity);
        setReorderLevel(reorderLevel);
        setSupplierId(supplierId);
        setWarrantyEndDate(warrantyEndDate);
        setExpiryDate(expiryDate);
    }

    // 3. getters
    public String getProductId() { return productId; }
    public String getName() { return name; }
    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }
    public int getReorderLevel() { return reorderLevel; }
    public String getSupplierId() { return supplierId; }
    public LocalDate getWarrantyEndDate() { return warrantyEndDate; }
    public LocalDate getExpiryDate() { return expiryDate; }

    public String getWarrantyEndText() {
        if (warrantyEndDate == null) {
            return "";
        }
        return warrantyEndDate.toString();
    }

    public String getExpiryDateText() {
        if (expiryDate == null) {
            return "";
        }
        return expiryDate.toString();
    }

    // 4. setters (they reject invalid values)
    public void setProductId(String productId) {
        if (productId == null || productId.trim().isEmpty()) {
            throw new InventoryException("Product ID cannot be empty.");
        }
        this.productId = productId.trim().toUpperCase().replace(",", "");
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new InventoryException("Product name cannot be empty.");
        }
        this.name = name.trim().replace(",", " ");
    }

    public void setUnitPrice(double unitPrice) {
        if (Double.isNaN(unitPrice) || Double.isInfinite(unitPrice) || unitPrice <= 0) {
            throw new InventoryException("Price must be greater than zero.");
        }
        this.unitPrice = unitPrice;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new InventoryException("Quantity cannot be negative.");
        }
        this.quantity = quantity;
    }

    public void setReorderLevel(int reorderLevel) {
        if (reorderLevel < 0) {
            throw new InventoryException("Reorder level cannot be negative.");
        }
        this.reorderLevel = reorderLevel;
    }

    public void setSupplierId(String supplierId) {
        if (supplierId == null) {
            this.supplierId = "";
        } else {
            this.supplierId = supplierId.trim().toUpperCase().replace(",", "");
        }
    }

    public void setWarrantyEndDate(LocalDate warrantyEndDate) {
        this.warrantyEndDate = warrantyEndDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    // 5. shared methods (the same for every category)
    public void addStock(int amount) {
        if (amount <= 0) {
            throw new InventoryException("Amount must be greater than zero.");
        }
        if (amount > Integer.MAX_VALUE - quantity) {
            throw new InventoryException("Stock would be more than the maximum allowed.");
        }
        quantity = quantity + amount;
    }

    public void removeStock(int amount) {
        if (amount <= 0) {
            throw new InventoryException("Amount must be greater than zero.");
        }
        if (amount > quantity) {
            throw new InventoryException("Not enough stock. Available: " + quantity + ".");
        }
        quantity = quantity - amount;
    }

    public double getInventoryValue() {
        return unitPrice * quantity;
    }

    public boolean isLowStock() {
        return quantity <= reorderLevel;
    }

    // Returns a warning text, or an empty text if there is no warranty problem
    public String getWarrantyAlert(LocalDate today, int daysAhead) {
        if (warrantyEndDate == null) {
            return "";
        }
        if (warrantyEndDate.isBefore(today)) {
            return "OUT OF WARRANTY (" + warrantyEndDate + ")";
        }
        if (!warrantyEndDate.isAfter(today.plusDays(daysAhead))) {
            return "WARRANTY ENDING SOON (" + warrantyEndDate + ")";
        }
        return "";
    }

    // Returns a warning text, or an empty text if there is no expiry problem
    public String getExpiryAlert(LocalDate today, int daysAhead) {
        if (expiryDate == null) {
            return "";
        }
        if (expiryDate.isBefore(today)) {
            return "EXPIRED (" + expiryDate + ")";
        }
        if (!expiryDate.isAfter(today.plusDays(daysAhead))) {
            return "EXPIRING SOON (" + expiryDate + ")";
        }
        return "";
    }

    @Override
    public String toCsvLine() {
        return getCategory() + "," + productId + "," + name + "," + unitPrice + ","
                + quantity + "," + reorderLevel + "," + supplierId + ","
                + getWarrantyEndText() + "," + getExpiryDateText() + ","
                + getSpecificationValue();
    }

    // 6. abstract methods: each child class MUST write its own version (POLYMORPHISM)
    public abstract String getCategory();
    public abstract String getSpecification();        // example: 550W
    public abstract String getSpecificationValue();   // example: 550
    public abstract void setSpecification(String value);
    public abstract double calculateStorageRisk();
}
