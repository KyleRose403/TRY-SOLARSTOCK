class Staff extends User {

    public Staff(String username, String password, String fullName) {
        super(username, password, fullName);
    }

    @Override
    public String getRole() {
        return "STAFF";
    }

    @Override
    public boolean canManageProducts() {
        return false;
    }
}
