// Interface: any class that can be written as one line of a CSV file.
// Product, Supplier and StockTransaction all implement it.
interface CsvRecord {
    String toCsvLine();
}
