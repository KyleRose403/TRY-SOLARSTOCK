import java.time.LocalDate;
import java.util.ArrayList;

// Prints the neat bordered tables. It only displays data; it has no inventory rules.
class TablePrinter {

    // Prints a border line like +-------+-------+ using the column widths
    public static void printLine(int[] widths) {
        System.out.print("+");
        for (int index = 0; index < widths.length; index++) {
            System.out.print("-".repeat(widths[index]));
            System.out.print("+");
        }
        System.out.println();
    }

    // Cuts long text so the table stays aligned
    public static String shorten(String text, int maxLength) {
        if (text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - 3) + "...";
    }

    public static void printProducts(ArrayList<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products to show.");
            return;
        }
        int[] widths = {10, 30, 14, 14, 10, 9, 10};
        printLine(widths);
        System.out.printf("| %-8s | %-28s | %-12s | %12s | %8s | %7s | %-8s |%n",
                "ID", "NAME", "CATEGORY", "PRICE (PHP)", "QTY", "REORDER", "SPEC");
        printLine(widths);
        for (Product product : products) {
            System.out.printf("| %-8s | %-28s | %-12s | %12.2f | %8d | %7d | %-8s |%n",
                    shorten(product.getProductId(), 8), shorten(product.getName(), 28),
                    product.getCategory(), product.getUnitPrice(), product.getQuantity(),
                    product.getReorderLevel(), shorten(product.getSpecification(), 8));
        }
        printLine(widths);
        System.out.println(products.size() + " product(s) shown.");
    }

    public static void printTransactions(ArrayList<StockTransaction> transactions) {
        if (transactions.isEmpty()) {
            System.out.println("No transactions recorded.");
            return;
        }
        int[] widths = {7, 21, 18, 12, 10, 32};
        printLine(widths);
        System.out.printf("| %-5s | %-19s | %-16s | %-10s | %8s | %-30s |%n",
                "NO.", "DATE AND TIME", "TYPE", "PRODUCT", "QTY", "NOTE");
        printLine(widths);
        for (StockTransaction transaction : transactions) {
            String note = transaction.getNote();
            if (transaction.isReversed()) {
                note = note + " [REVERSED]";
            }
            System.out.printf("| %-5d | %-19s | %-16s | %-10s | %8d | %-30s |%n",
                    transaction.getSequenceNumber(), transaction.getTimestampText(),
                    transaction.getType(), shorten(transaction.getProductId(), 10),
                    transaction.getQuantity(), shorten(note, 30));
        }
        printLine(widths);
    }

    public static void printSuppliers(ArrayList<Supplier> suppliers) {
        if (suppliers.isEmpty()) {
            System.out.println("No suppliers found.");
            return;
        }
        int[] widths = {10, 28, 30};
        printLine(widths);
        System.out.printf("| %-8s | %-26s | %-28s |%n", "ID", "NAME", "CONTACT");
        printLine(widths);
        for (Supplier supplier : suppliers) {
            System.out.printf("| %-8s | %-26s | %-28s |%n",
                    shorten(supplier.getSupplierId(), 8), shorten(supplier.getName(), 26),
                    shorten(supplier.getContact(), 28));
        }
        printLine(widths);
    }

    // Prints the 2D array made by Inventory.getCategorySummaryTable()
    public static void printCategorySummary(String[][] table) {
        int[] widths = {16, 11, 11, 22};
        printLine(widths);
        System.out.printf("| %-14s | %9s | %9s | %20s |%n",
                "CATEGORY", "PRODUCTS", "UNITS", "VALUE (PHP)");
        printLine(widths);
        for (int row = 0; row < table.length; row++) {
            System.out.printf("| %-14s | %9s | %9s | %20s |%n",
                    table[row][0], table[row][1], table[row][2], table[row][3]);
        }
        printLine(widths);
    }

    // Prints a ranking from the 2D array made by Inventory.getTopProducts()
    public static void printRanking(String[][] rows) {
        if (rows.length == 0) {
            System.out.println("No matching transaction history yet.");
            return;
        }
        int[] widths = {6, 10, 30, 10};
        printLine(widths);
        System.out.printf("| %-4s | %-8s | %-28s | %8s |%n", "RANK", "ID", "NAME", "UNITS");
        printLine(widths);
        for (int row = 0; row < rows.length; row++) {
            System.out.printf("| %-4d | %-8s | %-28s | %8s |%n", row + 1,
                    shorten(rows[row][0], 8), shorten(rows[row][1], 28), rows[row][2]);
        }
        printLine(widths);
    }

    // Inventory value and the storage risk score (each child class calculates its own risk)
    public static void printValueAndRisk(ArrayList<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products to show.");
            return;
        }
        int[] widths = {10, 30, 14, 18, 8};
        printLine(widths);
        System.out.printf("| %-8s | %-28s | %-12s | %16s | %6s |%n",
                "ID", "NAME", "CATEGORY", "VALUE (PHP)", "RISK");
        printLine(widths);
        for (Product product : products) {
            System.out.printf("| %-8s | %-28s | %-12s | %16.2f | %6.1f |%n",
                    shorten(product.getProductId(), 8), shorten(product.getName(), 28),
                    product.getCategory(), product.getInventoryValue(),
                    product.calculateStorageRisk());
        }
        printLine(widths);
    }

    public static void printDateAlerts(ArrayList<Product> products, int daysAhead) {
        LocalDate today = LocalDate.now();
        int[] widths = {10, 28, 36, 30};
        printLine(widths);
        System.out.printf("| %-8s | %-26s | %-34s | %-28s |%n",
                "ID", "NAME", "WARRANTY STATUS", "EXPIRY STATUS");
        printLine(widths);
        for (Product product : products) {
            String warrantyAlert = product.getWarrantyAlert(today, daysAhead);
            String expiryAlert = product.getExpiryAlert(today, daysAhead);
            if (warrantyAlert.isEmpty()) {
                warrantyAlert = "-";
            }
            if (expiryAlert.isEmpty()) {
                expiryAlert = "-";
            }
            System.out.printf("| %-8s | %-26s | %-34s | %-28s |%n",
                    shorten(product.getProductId(), 8), shorten(product.getName(), 26),
                    warrantyAlert, expiryAlert);
        }
        printLine(widths);
    }

    public static void printReceipt(ArrayList<CartItem> cart) {
        int[] widths = {26, 7, 14, 16};
        printLine(widths);
        System.out.printf("| %-24s | %5s | %12s | %14s |%n", "ITEM", "QTY", "PRICE", "TOTAL");
        printLine(widths);
        for (CartItem item : cart) {
            System.out.printf("| %-24s | %5d | %12.2f | %14.2f |%n",
                    shorten(item.getProduct().getName(), 24), item.getQuantity(),
                    item.getProduct().getUnitPrice(), item.getLineTotal());
        }
        printLine(widths);
    }
}
