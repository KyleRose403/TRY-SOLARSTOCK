import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * SOLARSTOCK - Solar Panel Distribution and Inventory Management System
 *
 * Compile: javac *.java
 * Run:     java SolarStock
 *
 * Accounts:  Admin -> admin / admin123
 *            Staff -> staff / staff123
 *
 * This is the USER INTERFACE class: it shows the menu, reads the input and
 * calls the Inventory methods. The inventory rules are inside Inventory.java.
 */
public class SolarStock {

    public static void main(String[] args) {
        // ----- Declare the objects here -----
        Scanner scanner = new Scanner(System.in);
        InputHelper input = new InputHelper(scanner);
        Inventory inventory = new Inventory();
        FileManager fileManager = new FileManager();
        ArrayList<User> users = new ArrayList<>();

        users.add(new Admin("admin", "admin123", "System Administrator"));
        users.add(new Staff("staff", "staff123", "Warehouse Staff"));

        // Load saved files. If there are none (or they are damaged), use the sample data.
        boolean dataLoaded = fileManager.loadAll(inventory);
        if (!dataLoaded) {
            loadSampleData(inventory);
        }

        System.out.println();
        System.out.println("==============================================");
        System.out.println("       SOLARSTOCK DISTRIBUTION SYSTEM");
        System.out.println("==============================================");

        User currentUser = login(input, users);
        if (currentUser == null) {
            System.out.println("Too many wrong attempts. Goodbye.");
            return;
        }

        // ----- Main menu (do-while and switch) -----
        int choice;
        do {
            showMenu(currentUser);
            choice = input.readInt("Choose: ", 0, 19);

            try {
                switch (choice) {
                    case 1:
                        if (canManage(currentUser)) {
                            handleAddProduct(inventory, input);
                        }
                        break;
                    case 2:
                        System.out.println("\nALL PRODUCTS");
                        TablePrinter.printProducts(inventory.getProducts());
                        break;
                    case 3:
                        handleSearchProduct(inventory, input);
                        break;
                    case 4:
                        if (canManage(currentUser)) {
                            handleUpdateProduct(inventory, input);
                        }
                        break;
                    case 5:
                        if (canManage(currentUser)) {
                            handleDeleteProduct(inventory, input);
                        }
                        break;
                    case 6:
                        handleStockIn(inventory, input);
                        break;
                    case 7:
                        handleStockOut(inventory, input);
                        break;
                    case 8:
                        handleLowStock(inventory);
                        break;
                    case 9:
                        handleSortProducts(inventory, input);
                        break;
                    case 10:
                        handleSummary(inventory);
                        break;
                    case 11:
                        System.out.println("\nTRANSACTION HISTORY");
                        TablePrinter.printTransactions(inventory.getTransactions());
                        break;
                    case 12:
                        handleSupplierMenu(inventory, input, currentUser);
                        break;
                    case 13:
                        handlePointOfSale(inventory, input);
                        break;
                    case 14:
                        handleAdvancedFilter(inventory, input);
                        break;
                    case 15:
                        handleDateAlerts(inventory);
                        break;
                    case 16:
                        handleUndo(inventory, input);
                        break;
                    case 17:
                        handleAnalytics(inventory);
                        break;
                    case 18:
                        handleExport(inventory, input, fileManager);
                        break;
                    case 19:
                        if (fileManager.saveAll(inventory)) {
                            System.out.println("Data saved.");
                        }
                        break;
                    default:
                        break;
                }
            } catch (InventoryException error) {
                // Any rule that is broken inside Inventory ends up here
                System.out.println("Error: " + error.getMessage());
            }

            // Save after every action so no data is lost
            fileManager.saveAll(inventory);
        } while (choice != 0);

        System.out.println("Data saved. Thank you for using SolarStock!");
    }

    // =================================================================
    // MENU AND LOGIN
    // =================================================================
    private static void showMenu(User currentUser) {
        System.out.println();
        System.out.println("==============================================");
        System.out.println(" User: " + currentUser.getFullName() + " | Role: " + currentUser.getRole());
        System.out.println("==============================================");
        System.out.println(" 1. Add Product");
        System.out.println(" 2. View All Products");
        System.out.println(" 3. Search Product");
        System.out.println(" 4. Update Product");
        System.out.println(" 5. Delete Product");
        System.out.println(" 6. Stock In (Restock)");
        System.out.println(" 7. Stock Out (Issue)");
        System.out.println(" 8. Low-Stock Alerts");
        System.out.println(" 9. Sort Products");
        System.out.println("10. Inventory Summary Report");
        System.out.println("11. Transaction History");
        System.out.println("12. Supplier Management");
        System.out.println("13. Point of Sale (POS)");
        System.out.println("14. Advanced Product Filters");
        System.out.println("15. Expiry and Warranty Alerts");
        System.out.println("16. Undo Last Stock Movement");
        System.out.println("17. Analytics Report");
        System.out.println("18. Export Reports (CSV/TXT)");
        System.out.println("19. Save Data Now");
        System.out.println(" 0. Exit");
    }

    private static User login(InputHelper input, ArrayList<User> users) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.println("\nLOGIN (attempt " + attempt + " of 3)");
            String username = input.readText("Username: ");
            String password = input.readText("Password: ");

            for (User user : users) {
                if (user.checkLogin(username, password)) {
                    System.out.println("Welcome, " + user.getFullName() + "!");
                    return user;
                }
            }
            System.out.println("Incorrect username or password.");
        }
        return null;
    }

    private static boolean canManage(User user) {
        if (user.canManageProducts()) {
            return true;
        }
        System.out.println("Access denied. Only Admin users can do this.");
        return false;
    }

    // =================================================================
    // PRODUCT FEATURES
    // =================================================================
    private static void handleAddProduct(Inventory inventory, InputHelper input) {
        String[] specificationPrompts = {
            "Panel wattage (W): ",
            "Inverter capacity (kW): ",
            "Battery capacity (Ah): "
        };

        System.out.println("\nADD PRODUCT");
        int categoryChoice = input.readInt("Category (1=Solar Panel, 2=Inverter, 3=Battery): ", 1, 3);
        String category = ProductFactory.CATEGORY_NAMES[categoryChoice - 1];

        // Keep asking until the ID is not a duplicate
        String productId;
        while (true) {
            productId = input.readText("Product ID: ").toUpperCase();
            if (inventory.findProductById(productId) == null) {
                break;
            }
            System.out.println("That product ID already exists. Try another ID.");
        }

        String name = input.readText("Product name: ");
        double unitPrice = input.readDouble("Unit price (PHP): ", 0.01, 100000000);
        int quantity = input.readInt("Initial quantity: ", 0, 1000000);
        int reorderLevel = input.readInt("Reorder level: ", 0, 1000000);
        String supplierId = askSupplierId(inventory, input);
        LocalDate warrantyEndDate = input.readDate("Warranty end date (YYYY-MM-DD): ");
        LocalDate expiryDate = input.readOptionalDate("Expiry date (YYYY-MM-DD, or press Enter for none): ");

        // Keep asking for the specification until the product can be created
        String specification = input.readText(specificationPrompts[categoryChoice - 1]);
        Product product;
        while (true) {
            try {
                product = ProductFactory.createProduct(category, productId, name, unitPrice,
                        quantity, reorderLevel, supplierId, warrantyEndDate, expiryDate, specification);
                break;
            } catch (InventoryException error) {
                System.out.println(error.getMessage() + " Try again.");
                specification = input.readText(specificationPrompts[categoryChoice - 1]);
            }
        }

        inventory.addProduct(product);
        System.out.println("Product added successfully.");
    }

    private static String askSupplierId(Inventory inventory, InputHelper input) {
        while (true) {
            String supplierId = input.readText("Supplier ID (type NONE if no supplier): ").toUpperCase();
            if (supplierId.equals("NONE")) {
                return "";
            }
            if (inventory.findSupplierById(supplierId) != null) {
                return supplierId;
            }
            System.out.println("Supplier not found. Add it in Supplier Management first, or type NONE.");
        }
    }

    private static void handleSearchProduct(Inventory inventory, InputHelper input) {
        System.out.println("\nSEARCH PRODUCT");
        System.out.println("1. Search by ID (exact)");
        System.out.println("2. Search by name (partial, not case-sensitive)");
        int choice = input.readInt("Choose: ", 1, 2);

        ArrayList<Product> results = new ArrayList<>();
        if (choice == 1) {
            Product product = inventory.findProductById(input.readText("Enter product ID: "));
            if (product != null) {
                results.add(product);
            }
        } else {
            results = inventory.searchByName(input.readText("Enter name or part of the name: "));
        }

        if (results.isEmpty()) {
            System.out.println("No product found.");
        } else {
            TablePrinter.printProducts(results);
        }
    }

    private static void handleUpdateProduct(Inventory inventory, InputHelper input) {
        Product product = inventory.findProductById(input.readText("Enter product ID to update: "));
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }

        System.out.println("Current record:");
        showOneProduct(product);

        String newName = input.readText("New name: ");
        double newPrice = input.readDouble("New price: ", 0.01, 100000000);
        int newReorderLevel = input.readInt("New reorder level: ", 0, 1000000);
        String prompt = "New " + product.getCategory() + " specification (number only): ";
        String newSpecification = input.readText(prompt);

        // Keep asking until the specification is accepted
        while (true) {
            try {
                inventory.updateProduct(product.getProductId(), newName, newPrice,
                        newReorderLevel, newSpecification);
                break;
            } catch (InventoryException error) {
                System.out.println(error.getMessage() + " Try again.");
                newSpecification = input.readText(prompt);
            }
        }

        System.out.println("Product updated:");
        showOneProduct(product);
    }

    private static void showOneProduct(Product product) {
        ArrayList<Product> single = new ArrayList<>();
        single.add(product);
        TablePrinter.printProducts(single);
    }

    private static void handleDeleteProduct(Inventory inventory, InputHelper input) {
        Product product = inventory.findProductById(input.readText("Enter product ID to delete: "));
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        showOneProduct(product);
        if (input.readYesNo("Delete this product? (Y/N): ")) {
            inventory.deleteProduct(product.getProductId());
            System.out.println("Product deleted.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    // =================================================================
    // STOCK MOVEMENTS
    // =================================================================
    private static void handleStockIn(Inventory inventory, InputHelper input) {
        Product product = inventory.findProductById(input.readText("Product ID: "));
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        int amount = input.readInt("Quantity to receive: ", 1, 1000000);
        Product updated = inventory.stockIn(product.getProductId(), amount);
        System.out.println("Stock received. New quantity: " + updated.getQuantity());
    }

    private static void handleStockOut(Inventory inventory, InputHelper input) {
        Product product = inventory.findProductById(input.readText("Product ID: "));
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        System.out.println("Available quantity: " + product.getQuantity());

        // Keep asking until the amount is accepted (0 cancels)
        while (true) {
            int amount = input.readInt("Quantity to issue (0 to cancel): ", 0, 1000000);
            if (amount == 0) {
                System.out.println("Stock out cancelled.");
                return;
            }
            try {
                Product updated = inventory.stockOut(product.getProductId(), amount);
                System.out.println("Stock issued. Remaining quantity: " + updated.getQuantity());
                if (updated.isLowStock()) {
                    System.out.println("!!! LOW STOCK WARNING: " + updated.getName()
                            + " is at or below its reorder level (" + updated.getReorderLevel() + ").");
                }
                return;
            } catch (InventoryException error) {
                System.out.println(error.getMessage() + " Try again.");
            }
        }
    }

    private static void handleLowStock(Inventory inventory) {
        System.out.println("\nLOW-STOCK PRODUCTS");
        ArrayList<Product> lowStockList = inventory.getLowStockProducts();
        if (lowStockList.isEmpty()) {
            System.out.println("No low-stock products.");
        } else {
            TablePrinter.printProducts(lowStockList);
        }
    }

    private static void handleSortProducts(Inventory inventory, InputHelper input) {
        System.out.println("\nSORT PRODUCTS");
        System.out.println("Sort by: 1=Name, 2=Price, 3=Quantity");
        int field = input.readInt("Choose: ", 1, 3);
        int direction = input.readInt("Direction (1=Ascending, 2=Descending): ", 1, 2);
        TablePrinter.printProducts(inventory.getSortedProducts(field, direction == 1));
    }

    // =================================================================
    // REPORTS
    // =================================================================
    private static void handleSummary(Inventory inventory) {
        System.out.println("\nINVENTORY SUMMARY REPORT");
        System.out.println("Total products : " + inventory.getProductCount());
        System.out.println("Total units    : " + inventory.getTotalUnits());
        System.out.printf("Total value    : PHP %,.2f%n", inventory.getTotalValue());

        System.out.println("\nCOUNT AND VALUE PER CATEGORY");
        TablePrinter.printCategorySummary(inventory.getCategorySummaryTable());

        System.out.println("\nLOW-STOCK LIST");
        handleLowStock(inventory);
    }

    private static void handleAdvancedFilter(Inventory inventory, InputHelper input) {
        System.out.println("\nADVANCED PRODUCT FILTER");
        System.out.println("Category: 0=All, 1=Solar Panel, 2=Inverter, 3=Battery");
        int categoryChoice = input.readInt("Choose category: ", 0, 3);
        String categoryName = "";
        if (categoryChoice > 0) {
            categoryName = ProductFactory.CATEGORY_NAMES[categoryChoice - 1];
        }
        double minPrice = input.readDouble("Minimum price: ", 0, 100000000);
        double maxPrice = input.readDouble("Maximum price: ", minPrice, 100000000);
        System.out.println("Stock status: 0=All, 1=Low stock, 2=In stock");
        int stockStatus = input.readInt("Choose status: ", 0, 2);

        ArrayList<Product> results = inventory.filterProducts(categoryName, minPrice, maxPrice, stockStatus);
        if (results.isEmpty()) {
            System.out.println("No products match those filters.");
        } else {
            TablePrinter.printProducts(results);
        }
    }

    private static void handleDateAlerts(Inventory inventory) {
        int daysAhead = 30;
        System.out.println("\nEXPIRY AND WARRANTY ALERTS (next " + daysAhead + " days)");
        ArrayList<Product> alerts = inventory.getProductsWithDateAlerts(daysAhead);
        if (alerts.isEmpty()) {
            System.out.println("No expired, expiring, or out-of-warranty products.");
        } else {
            TablePrinter.printDateAlerts(alerts, daysAhead);
        }
    }

    private static void handleUndo(Inventory inventory, InputHelper input) {
        StockTransaction last = inventory.getLastUndoableTransaction();
        if (last == null) {
            System.out.println("There is no stock movement to undo.");
            return;
        }
        System.out.println("Last stock movement: #" + last.getSequenceNumber() + " " + last.getType()
                + " | Product: " + last.getProductId() + " | Qty: " + last.getQuantity());
        if (input.readYesNo("Reverse this movement? (Y/N): ")) {
            inventory.undoLastStockMovement();
            System.out.println("Stock movement reversed and recorded in the history.");
        } else {
            System.out.println("Undo cancelled.");
        }
    }

    private static void handleAnalytics(Inventory inventory) {
        System.out.println("\nANALYTICS REPORT");

        System.out.println("\nTOP 5 BEST-SELLING PRODUCTS (POS sales)");
        TablePrinter.printRanking(inventory.getTopProducts("SALE", 5));

        System.out.println("\nTOP 5 MOST-ISSUED PRODUCTS (stock out)");
        TablePrinter.printRanking(inventory.getTopProducts("STOCK_OUT", 5));

        System.out.println("\nTOP 5 MOST VALUABLE PRODUCTS IN STOCK");
        TablePrinter.printValueAndRisk(inventory.getMostValuableProducts(5));

        System.out.println("\nSLOW MOVERS (no POS sale recorded)");
        ArrayList<Product> slowMovers = inventory.getSlowMovers();
        if (slowMovers.isEmpty()) {
            System.out.println("No slow movers.");
        } else {
            TablePrinter.printProducts(slowMovers);
        }

        System.out.println("\nSTORAGE RISK SCORES (each product type calculates its own)");
        TablePrinter.printValueAndRisk(inventory.getProducts());
    }

    // =================================================================
    // SUPPLIERS
    // =================================================================
    private static void handleSupplierMenu(Inventory inventory, InputHelper input, User currentUser) {
        int choice;
        do {
            System.out.println("\nSUPPLIER MANAGEMENT");
            System.out.println("1. Add Supplier (Admin only)");
            System.out.println("2. View Suppliers");
            System.out.println("3. Search Supplier");
            System.out.println("4. View Products by Supplier");
            System.out.println("5. Generate Supplier Restock List");
            System.out.println("0. Back");
            choice = input.readInt("Choose: ", 0, 5);

            try {
                switch (choice) {
                    case 1:
                        if (canManage(currentUser)) {
                            String supplierId = input.readText("Supplier ID: ");
                            String name = input.readText("Supplier name: ");
                            String contact = input.readText("Contact (number or email): ");
                            inventory.addSupplier(new Supplier(supplierId, name, contact));
                            System.out.println("Supplier added.");
                        }
                        break;
                    case 2:
                        TablePrinter.printSuppliers(inventory.getSuppliers());
                        break;
                    case 3:
                        TablePrinter.printSuppliers(
                                inventory.searchSuppliers(input.readText("Supplier ID or name: ")));
                        break;
                    case 4:
                        String searchId = input.readText("Supplier ID: ");
                        TablePrinter.printProducts(inventory.getProductsBySupplier(searchId));
                        break;
                    case 5:
                        String restockId = input.readText("Supplier ID: ");
                        System.out.println("RESTOCK LIST FOR " + restockId.toUpperCase());
                        ArrayList<Product> restockList = inventory.getRestockList(restockId);
                        if (restockList.isEmpty()) {
                            System.out.println("No products need restocking.");
                        } else {
                            TablePrinter.printProducts(restockList);
                        }
                        break;
                    default:
                        break;
                }
            } catch (InventoryException error) {
                System.out.println("Error: " + error.getMessage());
            }
        } while (choice != 0);
    }

    // =================================================================
    // POINT OF SALE
    // =================================================================
    private static void handlePointOfSale(Inventory inventory, InputHelper input) {
        ArrayList<CartItem> cart = new ArrayList<>();
        System.out.println("\nPOINT OF SALE");

        while (true) {
            String productId = input.readText("Product ID (or DONE to checkout): ");
            if (productId.equalsIgnoreCase("DONE")) {
                break;
            }
            Product product = inventory.findProductById(productId);
            if (product == null) {
                System.out.println("Product not found.");
                continue;
            }
            int quantity = input.readInt("Quantity: ", 1, 100000);
            try {
                inventory.checkCartQuantity(cart, product, quantity);
                cart.add(new CartItem(product, quantity));
                System.out.println("Added to cart.");
            } catch (InventoryException error) {
                System.out.println(error.getMessage());
            }
        }

        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        boolean loyaltyMember = input.readYesNo("Loyalty member? (Y/N): ");
        double subtotal = inventory.calculateSubtotal(cart);
        double discountPercent = inventory.calculateDiscountPercent(cart, loyaltyMember);
        double discount = inventory.calculateDiscountAmount(subtotal, discountPercent);
        double total = subtotal - discount;

        System.out.println("\nRECEIPT");
        TablePrinter.printReceipt(cart);
        System.out.printf("Subtotal : PHP %,.2f%n", subtotal);
        System.out.printf("Discount : PHP %,.2f (%.0f%%)%n", discount, discountPercent);
        System.out.printf("TOTAL    : PHP %,.2f%n", total);

        double cash = input.readDouble("Cash received: ", total, 1000000000);
        System.out.printf("CHANGE   : PHP %,.2f%n", cash - total);

        inventory.processSale(cart);
        for (CartItem item : cart) {
            if (item.getProduct().isLowStock()) {
                System.out.println("LOW STOCK: " + item.getProduct().getName());
            }
        }
        System.out.println("Sale completed. Inventory updated.");
    }

    // =================================================================
    // EXPORT
    // =================================================================
    private static void handleExport(Inventory inventory, InputHelper input, FileManager fileManager) {
        System.out.println("\nEXPORT REPORTS");
        System.out.println("1. Inventory report (CSV)");
        System.out.println("2. Transaction history (CSV)");
        System.out.println("3. Summary report (TXT)");
        System.out.println("0. Cancel");
        int choice = input.readInt("Choose report: ", 0, 3);
        if (choice == 0) {
            System.out.println("Export cancelled.");
            return;
        }

        String extension = ".csv";
        if (choice == 3) {
            extension = ".txt";
        }
        String fileName = askExportFileName(input, fileManager, extension);

        try {
            if (choice == 1) {
                fileManager.exportInventoryCsv(fileName, inventory);
            } else if (choice == 2) {
                fileManager.exportTransactionsCsv(fileName, inventory);
            } else {
                fileManager.exportSummaryTxt(fileName, inventory);
            }
            System.out.println("Export completed!");
            System.out.println("Saved to: " + fileManager.getFullPath(fileName));
        } catch (IOException error) {
            System.out.println("Could not export the report: " + error.getMessage());
        }
    }

    private static String askExportFileName(InputHelper input, FileManager fileManager, String extension) {
        while (true) {
            String name = input.readText("File name (without extension): ");

            if (name.matches(".*[\\\\/:*?\"<>|].*")) {
                System.out.println("Invalid file name. Do not use slashes or the characters : * ? \" < > |");
                continue;
            }
            if (name.toLowerCase().endsWith(extension)) {
                name = name.substring(0, name.length() - extension.length()).trim();
            }
            if (name.isEmpty() || name.equals(".") || name.equals("..")) {
                System.out.println("Please enter a valid file name.");
                continue;
            }

            String fileName = name + extension;
            if (fileManager.fileExists(fileName)) {
                if (!input.readYesNo("That file already exists. Overwrite it? (Y/N): ")) {
                    continue;
                }
            }
            return fileName;
        }
    }

    // =================================================================
    // SAMPLE DATA (uses a 2D array)
    // =================================================================
    private static void loadSampleData(Inventory inventory) {
        inventory.addSupplier(new Supplier("SUP001", "SunPower Trading", "0917-111-2222"));
        inventory.addSupplier(new Supplier("SUP002", "Green Energy Supply", "sales@greenenergy.example"));

        // Each row is one product:
        // category, id, name, price, quantity, reorder level, supplier, specification,
        // warranty ends in (days from today), expires in (days from today, blank = none)
        String[][] sampleData = {
            {"Solar Panel", "SP001",  "Jinko Monocrystalline 550W", "8500",  "100", "20", "SUP001", "550", "1825", ""},
            {"Solar Panel", "SP002",  "Longi Solar Panel 450W",     "7200",  "80",  "15", "SUP001", "450", "20",   ""},
            {"Solar Panel", "SP003",  "Canadian Solar 600W",        "9500",  "50",  "10", "SUP002", "600", "1825", ""},
            {"Inverter",    "INV001", "Hybrid Inverter 5kW",        "35000", "25",  "5",  "SUP002", "5",   "1825", ""},
            {"Inverter",    "INV002", "Grid-Tie Inverter 3kW",      "22000", "15",  "5",  "SUP001", "3",   "-5",   ""},
            {"Inverter",    "INV003", "Hybrid Inverter 10kW",       "65000", "3",   "3",  "SUP002", "10",  "1825", ""},
            {"Battery",     "BAT001", "Lithium Battery 10kWh",      "85000", "15",  "5",  "SUP002", "200", "1825", "2920"},
            {"Battery",     "BAT002", "Gel Battery 200Ah",          "18000", "30",  "8",  "SUP001", "200", "1825", "15"}
        };

        for (int row = 0; row < sampleData.length; row++) {
            LocalDate warrantyEndDate = LocalDate.now().plusDays(Integer.parseInt(sampleData[row][8]));
            LocalDate expiryDate = null;
            if (!sampleData[row][9].isEmpty()) {
                expiryDate = LocalDate.now().plusDays(Integer.parseInt(sampleData[row][9]));
            }
            Product product = ProductFactory.createProduct(
                    sampleData[row][0], sampleData[row][1], sampleData[row][2],
                    Double.parseDouble(sampleData[row][3]), Integer.parseInt(sampleData[row][4]),
                    Integer.parseInt(sampleData[row][5]), sampleData[row][6],
                    warrantyEndDate, expiryDate, sampleData[row][7]);
            inventory.addProduct(product);
        }
    }
}
