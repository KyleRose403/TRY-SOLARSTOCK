import java.time.LocalDate;

// Creates the correct kind of Product from a category name.
// It is used by the menu, by the file loader and by the sample data.
class ProductFactory {

    public static final String[] CATEGORY_NAMES = {"Solar Panel", "Inverter", "Battery"};

    public static Product createProduct(String category, String productId, String name,
                                        double unitPrice, int quantity, int reorderLevel,
                                        String supplierId, LocalDate warrantyEndDate,
                                        LocalDate expiryDate, String specification) {
        try {
            if (category.equals("Solar Panel")) {
                return new SolarPanel(productId, name, unitPrice, quantity, reorderLevel,
                        supplierId, warrantyEndDate, expiryDate,
                        Integer.parseInt(specification.trim()));
            } else if (category.equals("Inverter")) {
                return new Inverter(productId, name, unitPrice, quantity, reorderLevel,
                        supplierId, warrantyEndDate, expiryDate,
                        Double.parseDouble(specification.trim()));
            } else if (category.equals("Battery")) {
                return new Battery(productId, name, unitPrice, quantity, reorderLevel,
                        supplierId, warrantyEndDate, expiryDate,
                        Integer.parseInt(specification.trim()));
            }
        } catch (NumberFormatException error) {
            throw new InventoryException("The specification must be a number.");
        }
        throw new InventoryException("Unknown category: " + category);
    }
}
