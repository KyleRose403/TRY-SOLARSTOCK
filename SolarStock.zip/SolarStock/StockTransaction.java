import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

// One record of a stock movement or change (ADD, UPDATE, DELETE, STOCK_IN, STOCK_OUT, SALE, UNDO_...)
class StockTransaction implements CsvRecord {

    private int sequenceNumber;
    private String type;
    private String productId;
    private int quantity;
    private LocalDateTime timestamp;
    private String note;
    private boolean reversed;

    // Constructor 1: for a new transaction (the time is set automatically)
    public StockTransaction(int sequenceNumber, String type, String productId,
                            int quantity, String note) {
        this(sequenceNumber, type, productId, quantity, LocalDateTime.now(), note, false);
    }

    // Constructor 2: used when a transaction is loaded from the file
    public StockTransaction(int sequenceNumber, String type, String productId, int quantity,
                            LocalDateTime timestamp, String note, boolean reversed) {
        this.sequenceNumber = sequenceNumber;
        this.type = type;
        this.productId = productId;
        this.quantity = quantity;
        this.timestamp = timestamp;
        this.note = note.replace(",", " ");
        this.reversed = reversed;
    }

    public int getSequenceNumber() { return sequenceNumber; }
    public String getType() { return type; }
    public String getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getNote() { return note; }
    public boolean isReversed() { return reversed; }

    public void setReversed(boolean reversed) {
        this.reversed = reversed;
    }

    public String getTimestampText() {
        return timestamp.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    @Override
    public String toCsvLine() {
        return sequenceNumber + "," + type + "," + productId + "," + quantity + ","
                + timestamp + "," + note + "," + reversed;
    }
}
