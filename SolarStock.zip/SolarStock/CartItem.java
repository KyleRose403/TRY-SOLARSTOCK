// One line of the Point of Sale cart: a product and how many are being bought.
class CartItem {

    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }

    public double getLineTotal() {
        return product.getUnitPrice() * quantity;
    }
}
