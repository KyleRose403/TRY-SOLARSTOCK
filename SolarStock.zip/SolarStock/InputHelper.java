import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

// Reads keyboard input. Every method keeps asking until the input is valid,
// so wrong input shows an error message and a retry (never a crash).
class InputHelper {

    private Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine().trim();
            if (!text.isEmpty()) {
                return text;
            }
            System.out.println("Input cannot be empty. Try again.");
        }
    }

    public int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine().trim();
            try {
                int number = Integer.parseInt(text);
                if (number >= min && number <= max) {
                    return number;
                }
            } catch (NumberFormatException error) {
                // not a whole number: the message below is shown
            }
            System.out.println("Enter a whole number from " + min + " to " + max + ".");
        }
    }

    public double readDouble(String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine().trim();
            try {
                double number = Double.parseDouble(text);
                if (number >= min && number <= max) {
                    return number;
                }
            } catch (NumberFormatException error) {
                // not a number: the message below is shown
            }
            System.out.println("Enter a number from " + min + " to " + max + ".");
        }
    }

    public boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String answer = scanner.nextLine().trim();
            if (answer.equalsIgnoreCase("Y")) {
                return true;
            }
            if (answer.equalsIgnoreCase("N")) {
                return false;
            }
            System.out.println("Please enter Y or N.");
        }
    }

    public LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return LocalDate.parse(scanner.nextLine().trim());
            } catch (DateTimeParseException error) {
                System.out.println("Use the date format YYYY-MM-DD (example: 2030-12-31).");
            }
        }
    }

    // Same as readDate, but pressing Enter gives null (no date)
    public LocalDate readOptionalDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine().trim();
            if (text.isEmpty()) {
                return null;
            }
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException error) {
                System.out.println("Use YYYY-MM-DD or just press Enter for none.");
            }
        }
    }
}
