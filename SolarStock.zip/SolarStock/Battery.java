import java.time.LocalDate;

// INHERITANCE: Battery IS-A Product
class Battery extends Product {

    private int capacityAh;

    public Battery(String productId, String name, double unitPrice, int quantity,
                   int reorderLevel, String supplierId,
                   LocalDate warrantyEndDate, LocalDate expiryDate, int capacityAh) {
        super(productId, name, unitPrice, quantity, reorderLevel,
                supplierId, warrantyEndDate, expiryDate);
        setCapacityAh(capacityAh);
    }

    public int getCapacityAh() {
        return capacityAh;
    }

    public void setCapacityAh(int capacityAh) {
        if (capacityAh <= 0) {
            throw new InventoryException("Battery capacity must be greater than zero.");
        }
        this.capacityAh = capacityAh;
    }

    @Override
    public String getCategory() {
        return "Battery";
    }

    @Override
    public String getSpecification() {
        return capacityAh + "Ah";
    }

    @Override
    public String getSpecificationValue() {
        return String.valueOf(capacityAh);
    }

    @Override
    public void setSpecification(String value) {
        try {
            setCapacityAh(Integer.parseInt(value.trim()));
        } catch (NumberFormatException error) {
            throw new InventoryException("Battery capacity must be a whole number.");
        }
    }

    // Batteries that are close to expiry are the riskiest to keep in storage
    @Override
    public double calculateStorageRisk() {
        LocalDate expiry = getExpiryDate();
        if (expiry != null && !expiry.isAfter(LocalDate.now().plusDays(30))) {
            return 5.0;
        }
        return 2.0;
    }
}
