// Supplier is linked to products through the product's supplierId.
class Supplier implements CsvRecord {

    private String supplierId;
    private String name;
    private String contact;

    public Supplier(String supplierId, String name, String contact) {
        setSupplierId(supplierId);
        setName(name);
        setContact(contact);
    }

    public String getSupplierId() { return supplierId; }
    public String getName() { return name; }
    public String getContact() { return contact; }

    public void setSupplierId(String supplierId) {
        if (supplierId == null || supplierId.trim().isEmpty()) {
            throw new InventoryException("Supplier ID cannot be empty.");
        }
        this.supplierId = supplierId.trim().toUpperCase().replace(",", "");
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new InventoryException("Supplier name cannot be empty.");
        }
        this.name = name.trim().replace(",", " ");
    }

    public void setContact(String contact) {
        if (contact == null || contact.trim().isEmpty()) {
            throw new InventoryException("Supplier contact cannot be empty.");
        }
        this.contact = contact.trim().replace(",", " ");
    }

    @Override
    public String toCsvLine() {
        return supplierId + "," + name + "," + contact;
    }
}
