import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

// MANAGER CLASS: all the inventory rules live here (the menu class only calls these methods).
// Every product is stored in ONE list of the base type (Product).
// Polymorphism does the category work: this class never checks what kind of product it has.
class Inventory {

    private ArrayList<Product> products;
    private ArrayList<StockTransaction> transactions;
    private ArrayList<Supplier> suppliers;

    public Inventory() {
        products = new ArrayList<>();
        transactions = new ArrayList<>();
        suppliers = new ArrayList<>();
    }

    // ---------- getters (they return copies so the real lists stay protected) ----------
    public ArrayList<Product> getProducts() { return new ArrayList<>(products); }
    public ArrayList<StockTransaction> getTransactions() { return new ArrayList<>(transactions); }
    public ArrayList<Supplier> getSuppliers() { return new ArrayList<>(suppliers); }
    public int getProductCount() { return products.size(); }

    public void clearAll() {
        products.clear();
        transactions.clear();
        suppliers.clear();
    }

    // ---------- add, find, update, delete ----------
    public void addProduct(Product product) {
        if (product == null) {
            throw new InventoryException("Product cannot be empty.");
        }
        if (findProductById(product.getProductId()) != null) {
            throw new InventoryException("Duplicate product ID: " + product.getProductId());
        }
        if (!product.getSupplierId().isEmpty() && findSupplierById(product.getSupplierId()) == null) {
            throw new InventoryException("Supplier not found: " + product.getSupplierId());
        }
        products.add(product);
        recordTransaction("ADD", product.getProductId(), product.getQuantity(), "Product created");
    }

    // Used when loading from the file (no transaction is recorded)
    public void addLoadedProduct(Product product) {
        if (findProductById(product.getProductId()) != null) {
            throw new InventoryException("Duplicate product ID in saved data.");
        }
        products.add(product);
    }

    // RECURSION: look at one position, then ask the same method to look at the next one
    public Product findProductById(String productId) {
        if (productId == null) {
            return null;
        }
        return findProductRecursive(productId.trim().toUpperCase(), 0);
    }

    private Product findProductRecursive(String productId, int index) {
        if (index >= products.size()) {
            return null;                       // reached the end: not found
        }
        Product current = products.get(index);
        if (current.getProductId().equals(productId)) {
            return current;                    // found it
        }
        return findProductRecursive(productId, index + 1);
    }

    private Product getProductOrThrow(String productId) {
        Product product = findProductById(productId);
        if (product == null) {
            throw new InventoryException("Product not found.");
        }
        return product;
    }

    public ArrayList<Product> searchByName(String keyword) {
        ArrayList<Product> results = new ArrayList<>();
        String search = keyword.trim().toLowerCase();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(search)) {
                results.add(product);
            }
        }
        return results;
    }

    public void updateProduct(String productId, String newName, double newPrice,
                              int newReorderLevel, String newSpecification) {
        Product product = getProductOrThrow(productId);
        product.setSpecification(newSpecification);   // each child class checks its own value
        product.setName(newName);
        product.setUnitPrice(newPrice);
        product.setReorderLevel(newReorderLevel);
        recordTransaction("UPDATE", product.getProductId(), 0, "Product details updated");
    }

    public void deleteProduct(String productId) {
        Product product = getProductOrThrow(productId);
        products.remove(product);          // an ArrayList closes the gap by itself
        recordTransaction("DELETE", product.getProductId(), product.getQuantity(), "Product deleted");
    }

    // ---------- stock movements ----------
    public Product stockIn(String productId, int amount) {
        Product product = getProductOrThrow(productId);
        product.addStock(amount);
        recordTransaction("STOCK_IN", product.getProductId(), amount, "Restock");
        return product;
    }

    public Product stockOut(String productId, int amount) {
        Product product = getProductOrThrow(productId);
        product.removeStock(amount);       // refuses if there is not enough stock
        recordTransaction("STOCK_OUT", product.getProductId(), amount, "Stock issued");
        return product;
    }

    public ArrayList<Product> getLowStockProducts() {
        ArrayList<Product> lowStockList = new ArrayList<>();
        for (Product product : products) {
            if (product.isLowStock()) {
                lowStockList.add(product);
            }
        }
        return lowStockList;
    }

    // ---------- sorting (simple bubble sort) ----------
    // sortField: 1 = name, 2 = price, 3 = quantity, 4 = inventory value
    public ArrayList<Product> getSortedProducts(int sortField, boolean ascending) {
        ArrayList<Product> sortedList = new ArrayList<>(products);
        for (int pass = 0; pass < sortedList.size() - 1; pass++) {
            for (int index = 0; index < sortedList.size() - 1 - pass; index++) {
                Product first = sortedList.get(index);
                Product second = sortedList.get(index + 1);
                if (shouldSwap(first, second, sortField, ascending)) {
                    sortedList.set(index, second);
                    sortedList.set(index + 1, first);
                }
            }
        }
        return sortedList;
    }

    private boolean shouldSwap(Product first, Product second, int sortField, boolean ascending) {
        int result = compareProducts(first, second, sortField);
        if (ascending) {
            return result > 0;
        }
        return result < 0;
    }

    private int compareProducts(Product first, Product second, int sortField) {
        if (sortField == 1) {
            return first.getName().compareToIgnoreCase(second.getName());
        } else if (sortField == 2) {
            return Double.compare(first.getUnitPrice(), second.getUnitPrice());
        } else if (sortField == 3) {
            return Integer.compare(first.getQuantity(), second.getQuantity());
        }
        return Double.compare(first.getInventoryValue(), second.getInventoryValue());
    }

    // ---------- summary report ----------
    public int getTotalUnits() {
        return sumUnits(0);
    }

    // RECURSION: add the quantity at this position to the total of the rest
    private int sumUnits(int index) {
        if (index >= products.size()) {
            return 0;
        }
        return products.get(index).getQuantity() + sumUnits(index + 1);
    }

    public double getTotalValue() {
        return sumValue(0);
    }

    private double sumValue(int index) {
        if (index >= products.size()) {
            return 0;
        }
        return products.get(index).getInventoryValue() + sumValue(index + 1);
    }

    // Returns a 2D array. Each row = one category: {category, products, units, value}
    public String[][] getCategorySummaryTable() {
        TreeMap<String, Integer> productCounts = new TreeMap<>();
        TreeMap<String, Integer> unitCounts = new TreeMap<>();
        TreeMap<String, Double> values = new TreeMap<>();

        for (Product product : products) {
            String category = product.getCategory();   // polymorphism: the product tells us
            productCounts.put(category, productCounts.getOrDefault(category, 0) + 1);
            unitCounts.put(category, unitCounts.getOrDefault(category, 0) + product.getQuantity());
            values.put(category, values.getOrDefault(category, 0.0) + product.getInventoryValue());
        }

        String[][] table = new String[productCounts.size()][4];
        int row = 0;
        for (String category : productCounts.keySet()) {
            table[row][0] = category;
            table[row][1] = String.valueOf(productCounts.get(category));
            table[row][2] = String.valueOf(unitCounts.get(category));
            table[row][3] = String.format("%.2f", values.get(category));
            row++;
        }
        return table;
    }

    // ---------- advanced filters ----------
    // categoryName: "" means all categories. stockStatus: 0 = all, 1 = low stock, 2 = in stock
    public ArrayList<Product> filterProducts(String categoryName, double minPrice,
                                             double maxPrice, int stockStatus) {
        ArrayList<Product> results = new ArrayList<>();
        for (Product product : products) {
            boolean categoryMatches = categoryName.isEmpty()
                    || product.getCategory().equalsIgnoreCase(categoryName);
            boolean priceMatches = product.getUnitPrice() >= minPrice
                    && product.getUnitPrice() <= maxPrice;
            boolean stockMatches = stockStatus == 0
                    || (stockStatus == 1 && product.isLowStock())
                    || (stockStatus == 2 && !product.isLowStock());
            if (categoryMatches && priceMatches && stockMatches) {
                results.add(product);
            }
        }
        return results;
    }

    // ---------- suppliers ----------
    public void addSupplier(Supplier supplier) {
        if (findSupplierById(supplier.getSupplierId()) != null) {
            throw new InventoryException("Duplicate supplier ID: " + supplier.getSupplierId());
        }
        suppliers.add(supplier);
    }

    public void addLoadedSupplier(Supplier supplier) {
        suppliers.add(supplier);
    }

    public Supplier findSupplierById(String supplierId) {
        for (Supplier supplier : suppliers) {
            if (supplier.getSupplierId().equalsIgnoreCase(supplierId.trim())) {
                return supplier;
            }
        }
        return null;
    }

    public ArrayList<Supplier> searchSuppliers(String keyword) {
        ArrayList<Supplier> results = new ArrayList<>();
        String search = keyword.trim().toLowerCase();
        for (Supplier supplier : suppliers) {
            if (supplier.getSupplierId().equalsIgnoreCase(search)
                    || supplier.getName().toLowerCase().contains(search)) {
                results.add(supplier);
            }
        }
        return results;
    }

    public ArrayList<Product> getProductsBySupplier(String supplierId) {
        ArrayList<Product> results = new ArrayList<>();
        for (Product product : products) {
            if (product.getSupplierId().equalsIgnoreCase(supplierId.trim())) {
                results.add(product);
            }
        }
        return results;
    }

    public ArrayList<Product> getRestockList(String supplierId) {
        ArrayList<Product> results = new ArrayList<>();
        for (Product product : getProductsBySupplier(supplierId)) {
            if (product.isLowStock()) {
                results.add(product);
            }
        }
        return results;
    }

    // ---------- expiry and warranty alerts ----------
    public ArrayList<Product> getProductsWithDateAlerts(int daysAhead) {
        LocalDate today = LocalDate.now();
        ArrayList<Product> results = new ArrayList<>();
        for (Product product : products) {
            boolean warrantyAlert = !product.getWarrantyAlert(today, daysAhead).isEmpty();
            boolean expiryAlert = !product.getExpiryAlert(today, daysAhead).isEmpty();
            if (warrantyAlert || expiryAlert) {
                results.add(product);
            }
        }
        return results;
    }

    // ---------- point of sale ----------
    private int countInCart(ArrayList<CartItem> cart, Product product) {
        int total = 0;
        for (CartItem item : cart) {
            if (item.getProduct() == product) {
                total = total + item.getQuantity();
            }
        }
        return total;
    }

    public void checkCartQuantity(ArrayList<CartItem> cart, Product product, int quantity) {
        int alreadyInCart = countInCart(cart, product);
        if (alreadyInCart + quantity > product.getQuantity()) {
            throw new InventoryException("Not enough stock. Available: " + product.getQuantity()
                    + ", already in cart: " + alreadyInCart + ".");
        }
    }

    public double calculateSubtotal(ArrayList<CartItem> cart) {
        double subtotal = 0;
        for (CartItem item : cart) {
            subtotal = subtotal + item.getLineTotal();
        }
        return subtotal;
    }

    // Bulk discount: 10 or more units = 5%, 20 or more units = 10%. Loyalty member: extra 3%.
    public double calculateDiscountPercent(ArrayList<CartItem> cart, boolean loyaltyMember) {
        int totalUnits = 0;
        for (CartItem item : cart) {
            totalUnits = totalUnits + item.getQuantity();
        }
        double percent = 0;
        if (totalUnits >= 20) {
            percent = 10;
        } else if (totalUnits >= 10) {
            percent = 5;
        }
        if (loyaltyMember) {
            percent = percent + 3;
        }
        return percent;
    }

    public double calculateDiscountAmount(double subtotal, double discountPercent) {
        return subtotal * discountPercent / 100;
    }

    public void processSale(ArrayList<CartItem> cart) {
        // First check everything, so a sale is never half-finished
        for (CartItem item : cart) {
            if (countInCart(cart, item.getProduct()) > item.getProduct().getQuantity()) {
                throw new InventoryException("Not enough stock for " + item.getProduct().getName() + ".");
            }
        }
        for (CartItem item : cart) {
            item.getProduct().removeStock(item.getQuantity());
            recordTransaction("SALE", item.getProduct().getProductId(), item.getQuantity(), "POS sale");
        }
    }

    // ---------- undo ----------
    // Returns the newest stock movement that has not been reversed yet (or null)
    public StockTransaction getLastUndoableTransaction() {
        for (int index = transactions.size() - 1; index >= 0; index--) {
            StockTransaction transaction = transactions.get(index);
            String type = transaction.getType();
            boolean isStockMovement = type.equals("STOCK_IN") || type.equals("STOCK_OUT")
                    || type.equals("SALE");
            if (isStockMovement && !transaction.isReversed()) {
                return transaction;
            }
        }
        return null;
    }

    public StockTransaction undoLastStockMovement() {
        StockTransaction target = getLastUndoableTransaction();
        if (target == null) {
            throw new InventoryException("There is no stock movement to undo.");
        }
        Product product = findProductById(target.getProductId());
        if (product == null) {
            throw new InventoryException("Cannot undo: the product no longer exists.");
        }
        if (target.getType().equals("STOCK_IN")) {
            if (product.getQuantity() < target.getQuantity()) {
                throw new InventoryException("Cannot undo: some of the received stock was already used.");
            }
            product.removeStock(target.getQuantity());
        } else {
            product.addStock(target.getQuantity());
        }
        target.setReversed(true);
        recordTransaction("UNDO_" + target.getType(), product.getProductId(), target.getQuantity(),
                "Reversal of transaction #" + target.getSequenceNumber());
        return target;
    }

    // ---------- analytics ----------
    // Adds up the quantity per product for one transaction type (ignores reversed ones)
    private HashMap<String, Integer> getQuantityTotals(String transactionType) {
        HashMap<String, Integer> totals = new HashMap<>();
        for (StockTransaction transaction : transactions) {
            if (!transaction.isReversed() && transaction.getType().equals(transactionType)) {
                String productId = transaction.getProductId();
                totals.put(productId, totals.getOrDefault(productId, 0) + transaction.getQuantity());
            }
        }
        return totals;
    }

    // Returns a 2D array. Each row = one product: {productId, name, units}
    public String[][] getTopProducts(String transactionType, int topN) {
        HashMap<String, Integer> totals = getQuantityTotals(transactionType);
        ArrayList<String> productIds = new ArrayList<>(totals.keySet());

        // bubble sort, biggest quantity first
        for (int pass = 0; pass < productIds.size() - 1; pass++) {
            for (int index = 0; index < productIds.size() - 1 - pass; index++) {
                String first = productIds.get(index);
                String second = productIds.get(index + 1);
                if (totals.get(first) < totals.get(second)) {
                    productIds.set(index, second);
                    productIds.set(index + 1, first);
                }
            }
        }

        int rows = Math.min(topN, productIds.size());
        String[][] table = new String[rows][3];
        for (int row = 0; row < rows; row++) {
            String productId = productIds.get(row);
            Product product = findProductById(productId);
            table[row][0] = productId;
            if (product == null) {
                table[row][1] = "(deleted product)";
            } else {
                table[row][1] = product.getName();
            }
            table[row][2] = String.valueOf(totals.get(productId));
        }
        return table;
    }

    public ArrayList<Product> getMostValuableProducts(int topN) {
        ArrayList<Product> sortedList = getSortedProducts(4, false);
        ArrayList<Product> topList = new ArrayList<>();
        for (int index = 0; index < sortedList.size() && index < topN; index++) {
            topList.add(sortedList.get(index));
        }
        return topList;
    }

    public ArrayList<Product> getSlowMovers() {
        HashMap<String, Integer> soldTotals = getQuantityTotals("SALE");
        ArrayList<Product> slowMovers = new ArrayList<>();
        for (Product product : products) {
            if (!soldTotals.containsKey(product.getProductId())) {
                slowMovers.add(product);
            }
        }
        return slowMovers;
    }

    // ---------- transactions ----------
    private void recordTransaction(String type, String productId, int quantity, String note) {
        int sequenceNumber = transactions.size() + 1;
        transactions.add(new StockTransaction(sequenceNumber, type, productId, quantity, note));
    }

    public void addLoadedTransaction(StockTransaction transaction) {
        transactions.add(transaction);
    }
}
