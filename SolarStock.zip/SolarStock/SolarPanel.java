import java.time.LocalDate;

// INHERITANCE: SolarPanel IS-A Product
class SolarPanel extends Product {

    private int wattage;

    public SolarPanel(String productId, String name, double unitPrice, int quantity,
                      int reorderLevel, String supplierId,
                      LocalDate warrantyEndDate, LocalDate expiryDate, int wattage) {
        super(productId, name, unitPrice, quantity, reorderLevel,
                supplierId, warrantyEndDate, expiryDate);
        setWattage(wattage);
    }

    public int getWattage() {
        return wattage;
    }

    public void setWattage(int wattage) {
        if (wattage <= 0) {
            throw new InventoryException("Wattage must be greater than zero.");
        }
        this.wattage = wattage;
    }

    @Override
    public String getCategory() {
        return "Solar Panel";
    }

    @Override
    public String getSpecification() {
        return wattage + "W";
    }

    @Override
    public String getSpecificationValue() {
        return String.valueOf(wattage);
    }

    @Override
    public void setSpecification(String value) {
        try {
            setWattage(Integer.parseInt(value.trim()));
        } catch (NumberFormatException error) {
            throw new InventoryException("Wattage must be a whole number.");
        }
    }

    @Override
    public double calculateStorageRisk() {
        if (wattage > 600) {
            return 2.0;
        }
        return 1.0;
    }
}
