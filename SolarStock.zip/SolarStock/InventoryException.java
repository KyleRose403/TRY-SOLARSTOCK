// Our own exception class. It is thrown when an inventory rule is broken.
class InventoryException extends RuntimeException {

    public InventoryException(String message) {
        super(message);
    }
}
