SolarStock - Solar Panel Distribution and Inventory Management System

Compile:  javac *.java
Run:      java SolarStock        (main file: SolarStock.java)

Logins:   admin / admin123   |   staff / staff123
Data is saved automatically to products.csv, suppliers.csv and transactions.csv
in the folder you run the program from.
